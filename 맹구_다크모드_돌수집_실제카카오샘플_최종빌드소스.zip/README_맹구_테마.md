# 맹구 다크모드 + 돌 수집

카카오 26.8.0 공식 Android 샘플 소스를 기반으로 수정한 빌드용 프로젝트입니다.

필요 환경: JDK 21, Android SDK Platform 35, Android SDK Build-Tools 35.x.
빌드: `./gradlew assembleDebug`
출력: `build/outputs/apk/debug/`

이 실행 환경에는 Android SDK/Build Tools가 없어 여기서 APK 컴파일까지는 수행하지 못했습니다. Android 공식 문서의 API 35 설정은 Platform 35 및 Build-Tools 35.x 설치를 요구합니다.
